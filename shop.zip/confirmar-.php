<?php include "header.php" ?>
<br>
Ya eres usuario?<br>
<form action="login.php" method="POST">

		<input type="text" name="usuario" placeholder="Introduce tu nombre de usuario">
		<input type="text" name="contrasena" placeholder="Introduce tu contraseña">
		<input type="submit">
		</form>
		
		Eres nuevo usuario<br>

		