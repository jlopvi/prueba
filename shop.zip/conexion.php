<?php
	$conexion = mysqli_connect("localhost", "root", "", "tien");
	mysqli_set_charset($conexion, "utf8");
