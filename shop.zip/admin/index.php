<a href='pedidos.php'>Gestionar pedidos</a>
<a href='clientes.php'>Gestionar Clientes</a>
<a href='productos.php'>Gestionar Productos</a>